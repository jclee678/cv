import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import { Globals } from './globals';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class DemoService {
    public globalVars;

    constructor(private http:HttpClient, private globals: Globals) {
        this.globalVars = globals;
    }

    
    getTransactionFlow(docId) { 
       return this.http.get(this.globalVars.urlRoot + '/transactionChain/'+docId); 
    }
    
    getRelatedDoc() {
        return this.http.get(this.globalVars.urlRoot + '/transactionForUser/1');
    }
    
    getMyId() {
         return this.http.get(this.globalVars.urlRoot + '/myId');   
    }
    
    
    decrypt(senderId, fileId) {
        return this.http.get(this.globalVars.urlRoot + '/decryptFile/'+senderId+'/'+fileId);       
    }


}
